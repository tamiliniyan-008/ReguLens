# RegulaLens

**AI-assisted Regulatory Impact & Compliance Intelligence** — Team DeepMinds, selfE Hackathon.

> Decision-support prototype. All bundled data is fictional. Findings are *potential issues requiring human review*, never legal advice.

**Live demo:** _paste your demo link here_

## Problem
Organizations struggle to work out how evolving regulations affect their existing contracts, financial transactions and business entities. Manual reviews are slow, and compliance gaps are hard to trace back to supporting evidence.

## Solution
RegulaLens connects regulatory requirements with contract clauses and transaction records, flags potential compliance gaps, checks regulatory effective dates, and presents evidence-backed findings with transparent risk indicators and human review.

## What makes it different
Most tools summarise a law. RegulaLens builds a **traceable chain**: regulatory clause → matched contract clause → linked transactions → finding → recorded human decision. Every flag opens to its source text and records.

## Workflow (in the app)
1. **Upload** – regulation, contract and ledger CSV (or load the demo scenario)
2. **Match** – TF-IDF cosine similarity pairs each clause with the closest contract clause
3. **Findings** – highlighted evidence, timing check, risk, confidence and exposure, shown separately
4. **Evidence graph** – labeled relationships from document to decision
5. **Dashboard** – totals, risk distribution, statuses, recent reviews
6. **Audit** – every review action logged and exportable as CSV

## How findings are assessed
- **Matching:** TF-IDF + cosine similarity (implemented in JavaScript), with time-limit comparison. Similarity means "possibly related", not "violation".
- **Timing:** each rule is *potentially applicable*, *potentially outside the effective period* or *uncertain*. No retroactivity is assumed.
- **Risk (0–100):** prototype heuristic = 35% severity + 25% evidence strength + 15% affected transactions + 25% timing applicability. Not a validated model.
- **Confidence:** shown separately from risk.
- **Exposure:** sum of linked payments after the effective date, only when the data supports it. It is **not** a fine or penalty; otherwise "Not estimated".

## Tech stack
HTML, CSS, JavaScript (no build step, no dependencies), in-browser TF-IDF, SVG evidence graph, localStorage for the audit trail.

## Run locally
Open `index.html` in any browser, or:
```
python -m http.server 8000
```
then visit http://localhost:8000. Click **Load demo scenario**.

## Deploy (GitHub Pages)
Repository **Settings → Pages → Deploy from a branch → `main` / root**. The site is served at `https://<your-username>.github.io/<repo-name>/`.

## Sample data
`sample_data/` holds the fictional regulation, contract and ledger. Upload them in the Upload step to reproduce the demo.

## Known limitations
- Accepts `.txt` and `.csv` only (no PDF/OCR in this version).
- Review decisions are stored in the browser (localStorage), not a database.
- Rule-based and statistical matching only; no LLM; no jurisdiction or retroactivity reasoning.
- No automated tests yet.

## Future improvements
PDF extraction with page numbers, SQLite persistence, editable clause dates, multi-jurisdiction conflict checks, automated tests.

## References
- NIST AI Risk Management Framework — https://www.nist.gov/itl/ai-risk-management-framework
- FCA Regulatory Initiatives Grid — https://www.fca.org.uk/publications/corporate-documents/regulatory-initiatives-grid
- EBA Supervisory Reporting — https://www.eba.europa.eu/regulation-and-policy/supervisory-reporting
